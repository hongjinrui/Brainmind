# 验证记录

日期：2026-11-10，Windows 稳定性复核。结论：**已有 BRZ 的 11 项操作演示，以及直接由内容创建的 38 节点 NIST AI RMF 脑图，均在 TheBrain 14.0.102.0 中完成导入、关闭重开和再导出。** 自动化检查与界面检查的具体范围分别记录如下；这些结果不保证任意归档或未来版本没有问题。

## 自动检查

历史 Linux 检查在 Python 3.12.14 环境执行：

```sh
python3 -X utf8 -m unittest discover -s tests -v
```

当时 63 项测试通过，其中一项以子测试逐一读取本仓库恢复出的五份原始 BRZ。随后 Windows 的 Python 3.13.13 实测暴露了只读文件描述符调用 `fsync` 失败的问题；修复为可写描述符后，64 项测试通过。加入原生导出与边界回归后为 75 项；再加入 NIST 示例生成器的 3 项回归后，本地 Windows 共 **78 项测试通过**，包含五份真实样例。其余测试使用自包含样本，不依赖安装器或第三方库；尚未恢复 `work/extracted` 的环境会明确跳过实样本检查。

覆盖名称与 UUID、父子/跳转、类型/标签同步、多个同名节点、Markdown 笔记及 UTF-8 字节长度、保留 HTML、受限图标模板、已有属性值、背景色、计划哈希和事务回退、禁止覆盖、未知文件/字段、原始行和 ZIP 元数据保留，以及重复键、非有限数值、重复成员、路径穿越、加密与符号链接拒绝。CLI 另验证预演不写文件、写后重新读取校验及笔记截断标志。

既有回归重点：相同类型/标签不重建记录、删除连线不遗留附属内容、类型替换不丢样式、新类型/标签官方默认值、最新笔记的缓存标记、整数/小数属性约束、JSON 精度损失拒绝、已知来源引用校验、写入发布前重读与比较报告。

本轮补充 Windows 文件同步、UTF-8 CLI 输出、原生 `access.json` 复合键、再导出壁纸的旧脑图来源保留，以及笔记文件独占性检查。UTF-8 回归通过真实子进程强制旧代码页，检查中文/emoji 名称、笔记和输出路径；笔记回归检查另一附件共用 `Notes.md` 时不覆盖，也不因文件暂缺就错误创建内容。壁纸特例要求已观察到的全部标志、内嵌成员存在及长度一致，其他悬空来源继续拒绝。

另按 skill 独立执行一次真实样例的 9 操作流程，覆盖中文/emoji、父子、跳转、类型、标签、颜色、笔记、预演与写出比较。原件及无关成员字节不变；已有输出、输入输出相同、过期摘要、未知参数、UUID 冲突和计划后段失败六种情况均正确拒绝，没有部分结果。skill 结构校验也通过。

第一批稳定性修复提交 `e7f3b34489a14d41601d34d26a6c8916cc1de6da` 已完成 [GitHub Actions 运行 42829276774](https://github.com/hongjinrui/Brainmind/actions/runs/42829276774)：Ubuntu/Windows × Python 3.10/3.13/3.14，共 6 组全部通过。该运行覆盖当时的 75 项测试，未提供原始 BRZ 的 CI 环境明确跳过实样本项；不包含后来新增的 3 项示例生成器测试。配置见 [.github/workflows/tests.yml](https://github.com/hongjinrui/Brainmind/blob/main/.github/workflows/tests.yml)，后续提交须核对自身运行结果。

技能单独安装后又进行了独立使用测试：从安装的 `SKILL.md` 定位工具，以原始 2 节点 `test2` 为输入，新增“PDF 阅读验证”子节点和中文来源笔记。读取、预演、写出、校验、比较及笔记回读全部通过；结果为 3 节点、2 连线、2 附件，新增 3 条记录且未修改或删除原记录，10 个无关成员字节和输入 SHA-256 不变。此测试证明本机已安装 skill 的 CLI 流程可执行，不包含桌面导入或 PDF 内容阅读。

所有五份原始导出的 `validation.errors` 均为空。`test2 (1)` 原本就有一条壁纸 `DataLength` 不一致警告，编辑副本保留该警告，没有改动壁纸。

## 无底稿创建与独立 skill 包

新增 `create --content` 后，测试覆盖没有输入 BRZ 的创建、全新实体身份、脑图名称和主页设置、中文/emoji、同名节点、多父关系、父子环及重复关系拒绝、总操作数上限、内容 JSON 严格解析、禁止覆盖、写出后重读，以及生成文件继续 `apply` 编辑。测试中还使普通 `Archive` 读入构造器直接失败，确认新建过程没有暗中读取 seed。合计 **91 项测试在本地 Windows 通过**，包含 9 项新建测试和 4 项独立包测试；已有 CI 记录仍只对应其注明的历史提交。

[package_skill.py](https://github.com/hongjinrui/Brainmind/blob/main/tools/package_skill.py) 从唯一核心源码构建完整包，固定成员顺序、时间戳、权限和文本换行，并采用 ZIP_STORED。测试确认两次构建逐字节一致，`manifest.json` 覆盖全部有效载荷且每个 SHA-256 都匹配，输出存在时不覆盖，发布失败时清除临时文件。只读 `--check` 会将发布包与当前源码重建结果逐字节比较，陈旧或缺失的包使 CI 失败；回归测试同时验证该检查不改写被检查文件。

独立包测试将 ZIP 解压到含中文和空格的临时目录，再从另一个工作目录用 Python `-I` 隔离模式调用包内启动器；此模式不会借用当前目录或 `PYTHONPATH` 的仓库模块。使用包内内容示例完成预演、创建、校验、名称与中文笔记读取，再给生成节点修改 Label 并比较。整个流程无需 Git、源 BRZ、安装程序或第三方 Python 包，原生成文件保持不变。PDF 的阅读与内容整理仍由模型及其阅读工具完成。

另外安排独立使用者只从候选 ZIP 内的 skill、文档及 CLI 帮助开始，在包外目录以 `python -I` 运行，并移除 `PYTHONPATH`、`PYTHONHOME`。将三条自写中文阅读笔记组织成 4 节点、3 父子、1 跳转及 4 份 Markdown 的新脑图，再定位 UUID 并修改一个 Label；预演、创建、继续编辑、校验及比较全部通过，无依赖定位卡点。输入归档 SHA-256 未变，二次文件只变更目标节点的 Label/修改时间，节点身份及笔记字节保持不变。此项为离线独立使用验证，未操作桌面应用。

独立 ZIP 加公开 PDF 的另一轮试用产生了 8 节点、7 条父子关系、3 条跳转、8 份笔记及 7 个浅色节点的作品。该文件在 TheBrain 14.0.102.0 中直接选择创建新脑图导入并打开，界面抽查根节点和“有效且可靠”，确认中文来源页码、浅色背景及到“公平与偏差”的跳转。该 8 节点样例仅完成导入与打开抽查，未单独重开或再导出；下方 38 节点样例覆盖完整往返流程。

无底稿创建最初试验发现了空 `settings` 归档导入后无法打开的问题，已依据官方设置枚举、UUID 算法与原生样本增加脑图名称和主页设置；技术证据见 [FORMAT.md](FORMAT.md#无底稿创建)。修正后的 3 节点小样例已在 TheBrain 14.0.102.0 中直接导入新脑图并打开，脑图名称、主页、3 份笔记及显式黄色背景均在界面确认。

随后直接用 `create` 处理 NIST 的 [content.json](https://github.com/hongjinrui/Brainmind/blob/main/examples/nist-ai-rmf/content.json)，生成 38 节点、37 条父子关系、13 条跳转及 38 份来源笔记，全程没有输入 BRZ。成品 SHA-256 为 `01e0b387e6d357f0535c6da9793ce53584e0696ffc5fc4714c15c5f555d392e7`。在原应用选择“创建新脑图”导入、打开、关闭、从列表重开，查看根节点、七维度分支、“有效且可靠”的跳转及中文来源笔记，再原生导出。原生导出摘要为：

```text
f4110b4ff0eee627cb621c287a20b949ae5af02f0457221e103777f47f0548ac
```

全量数据核对确认 38 个名称、38 份笔记的全部字节及来源引用、37 条父子方向、13 条跳转、BrainId、全部节点 UUID、脑图名称和主页设置均保留。此内容 JSON 没有显式背景色，导入前后均为 0 项显式颜色；前述黄色小样例单独覆盖颜色显示。应用新增 1 条 `MinimumVersionRecommended` 设置、1 条修改日志、2 条 syncpoint 和 3 个 `ActivationDateTime` 字段；另外 33 个时间字段只做字符串格式规范化，meta 无变化。原生导出校验为 `errors=[]`、`warnings=[]`。

再以该原生导出为输入，通过已安装 skill 仅修改一个目标节点的 Label。只有 `thoughts.json` 成员改变，另外 50 个成员字节、38 份笔记、50 条关系及设置均保持不变；输入 SHA-256 未变，输出校验仍无错误、无警告。二次输出 SHA-256 为 `4d7967c9df30663c0a92e4921eed71753b6be98dc0a95d81680f8be2cbf90c4f`。这次二次编辑未再次导入应用，结论限定为继续离线维护成功。

## 真实 BRZ 修改演示

输入：`TheBrain14 - v2/test2 2025-03-21 (1).brz`。

输入 SHA-256：

```text
77b752d502b643830a88a05279df7b9f5c5af42391addcbf848fbaf7a88b13a5
```

按 [demo.plan.json](https://github.com/hongjinrui/Brainmind/blob/main/examples/demo.plan.json) 的 11 个操作重新生成 [test2-code-edit-demo.brz](https://github.com/hongjinrui/Brainmind/blob/main/examples/test2-code-edit-demo.brz)，修改清单和摘要见 [demo.report.json](https://github.com/hongjinrui/Brainmind/blob/main/examples/demo.report.json)，逐字段/成员变化见 [demo.diff.json](https://github.com/hongjinrui/Brainmind/blob/main/examples/demo.diff.json)。

- 原“加法”改为“加法（代码修改验证）”并增加 Label，保留原 UUID。
- 新增普通节点“代码编辑验证”、标签“代码验证”和类型“代码验证类型”。
- “test2”成为新普通节点的父节点；新普通节点与原“加法”建立跳转联系。
- 为新普通节点设置背景色、类型、标签及中文 Markdown 笔记。
- 将“已学”的 PNG 图标按已研究的简单模板复用到新类型节点。

| 项目 | 修改前 | 修改后 |
| --- | ---: | ---: |
| 节点 | 14 | 17 |
| 连线 | 15 | 19 |
| 附件记录 | 8 | 10 |
| ZIP 成员 | 20 | 22 |

输出 SHA-256：

```text
3e4d9973eb67a3d71f0a78da2a1472134b5ac5c131642727c94fe17d7fcaa0a5
```

将这份已提交的演示输出重新打开并校验：`errors=[]`。程序重新读取新增笔记，内容完整且未截断。这一步是离线验证；后来在 Windows 重新生成的同计划副本进行了下面的应用验收。

本次重建还核对了上一版遗漏的三个状态：新普通节点的非空笔记标记为 `True`、新标签图标前缀为 `8`、新类型具有与名称一致的默认 `Label`。

文件范围比对结果：

- 四份原始分卷和五份恢复出的原始 BRZ，与 [INVENTORY.json](INVENTORY.json) 中的 SHA-256 全部一致。
- 原有 20 个成员均保留；16 个成员的解压后字节完全未变。
- 仅四个现有成员发生变化：`meta.json`、`thoughts.json`、`links.json`、`attachments.json`。
- 原有节点记录中，仅原“加法”发生计划内修改；其余原有节点、连线、附件记录的原始行不变。
- 仅新增新普通节点的 `Notes.md` 和新类型节点的 `.data/Icon.png` 两个成员。

重新执行计划会产生新的时间戳，以及未显式指定的新 link/附件 UUID，因此文件摘要可能不同；应核对语义和变更范围，不要求重新生成的 ZIP 与本次输出逐字节相同。

## 官方数据模型往返检查

在 Linux 上使用本地 .NET 6 和官方 `TheBrainCore.dll` / `Newtonsoft.Json.dll`，对五份原始 BRZ 加修订演示的节点、连线、附件、属性定义、属性实例共 **876 条记录**，实际执行了反序列化、重新序列化及原有键值的语义比对。全部通过，没有原有键值的语义差异；时间字符串尾随零的规范化单独记录。

这比 Python 自己读写自己的格式更有证据力，但使用的是官方数据模型与 JSON 库，**没有调用归档导入器、写入应用数据库或启动界面**。完整方法、复现命令和结果见 [OFFICIAL-MODEL-CHECK.md](OFFICIAL-MODEL-CHECK.md)。

## 原应用导入、重开和再导出

环境：Windows，TheBrain **14.0.102.0**。采用可丢弃的完整 `test2` 测试副本，导入重新生成的 11 操作演示；未合并进日常脑图。导入副本 SHA-256 为 `062c21d5fee62f5f8058931906395ebe60bec5f02b2b47c861161d1d0b5f4953`。

应用界面确认改名后的“加法（代码修改验证）”、“代码编辑验证”的黄色背景、继承图标、中文 Markdown、父子和跳转关系。关闭测试脑图、重新打开后内容仍在；再用原应用导出新 BRZ，SHA-256 为 `37facf82574b40df62ca9d7c558badc4e9212fa939542d8a1cee8ea942f56827`。

应用重分配了 UUID，因此另按节点类别、关系端点和计划逐项核对，未把按 UUID 的增删当作内容丢失。结果：**11 项操作全部保留，原有 19 条语义关系存在，10 条附件记录均可对应，9 份内嵌文件字节一致**。再导出含 18 个节点、20 条连线，较导入文件多一个 `Pinned` 系统节点及一条 `test2` 自连接；这些应用产生的变化单独记录，不据总数相等判断成功。

这次原生导出暴露了旧校验器的两项假设：访问记录必须有 `Id`，以及所有壁纸 `SourceId` 必须等于当前脑图 ID。本轮按原生样本修订为复合键及严格受限的壁纸警告，规则见 [FORMAT.md](FORMAT.md#容器与记录) 和[附件说明](FORMAT.md#笔记图标和附件)。不删除访问记录、不伪造 UUID，也不修改壁纸归属来让测试通过。

## 公开 PDF 成品：NIST AI RMF 1.0

来源为 NIST 的 [Artificial Intelligence Risk Management Framework (AI RMF 1.0)](https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf)，内容固定解释 2023 年 1.0 版。中文结构、摘要和原创实践提示见 [content.json](https://github.com/hongjinrui/Brainmind/blob/main/examples/nist-ai-rmf/content.json)；每份笔记标明来源页码及 PDF 链接，区分资料概括与原创提示，不作为官方译文或 NIST 背书。PDF 仅以链接引用，不嵌入 BRZ。

制作使用 TheBrain 原生导出的 1 节点空白测试脑图，保留其原件，由 [build_plan.py](https://github.com/hongjinrui/Brainmind/blob/main/examples/nist-ai-rmf/build_plan.py) 生成 133 操作计划，经 CLI 预演、写副本和比较产生“AI 风险管理：从框架到行动”。复现方法见[示例说明](https://github.com/hongjinrui/Brainmind/blob/main/examples/nist-ai-rmf/README.md)。结果含 38 个普通节点、37 条父子关系、13 条跳转、38 份中文来源笔记，7 个主分支各有背景色。

在 Windows 的 TheBrain **14.0.102.0** 中，将成品导入独立测试脑图，关闭并重新打开，随后完成原生再导出。界面抽查范围为根节点、“可信 AI 的七个维度”分支、“有效且可靠”节点的跳转及中文笔记。原生导出文件 SHA-256 为：

```text
ae69836e9c16a46b0546958754dd6a5871b4af8f5345174b1be14f7839e6a1cf
```

这份原生导出的 CLI 校验为 `errors=[]`、`warnings=[]`。全量数据核对确认：38 个名称、38 份 Markdown 的全部字节、37 条父子方向、13 条跳转、7 个分支背景色，以及全部 38 份笔记中的来源页码链接均保留；`BrainId` 和 38 个节点 UUID 也未变。应用产生的其他变化为 22 处时间格式规范化、2 个新增 `ActivationDateTime` 字段及 1 条新增 syncpoint，`meta.json` 无变化。

随后以该原生再导出文件为输入，重新绑定其 SHA-256，为“有效且可靠”增加 Label，并在完整原笔记末尾追加阅读检查点。二次编辑的预演、写出、校验和比较通过，仍为 `errors=[]`、`warnings=[]`；其余 37 份笔记、全部 50 条关系和 7 个分支颜色保持不变。仅 `thoughts.json`、`attachments.json` 及目标 `Notes.md` 三个成员变化，另外 48 个成员字节未变，输入 SHA-256 未变。二次编辑输出摘要为：

```text
2648fec364c8eb21dc828b5a0dc1da917a70ae838c7b749f77e7416260e61501
```

二次编辑完成的是 CLI 数据验收，尚未再次导入桌面应用。上述证据覆盖本次生成、导入、重开、导出及继续离线编辑的流程；其他版本、附件类型和输入仍需各自验证。

## 静态程序证据与应用测试边界

早期 Linux 格式研究只对官方安装器进行静态提取，检查官方程序集元数据和运行配置；离线编辑流程不执行包内安装器或授权工具：

| 文件 | SHA-256 |
| --- | --- |
| `TheBrain 14.0.102.0 Installer.exe` | `231b8c6bad468b031bcc283c109fa8f117f4574cff0211f15c5d5fe9ca9324d6` |
| 官方载荷 `TheBrainCore.dll` | `70356c4e3c243b8072d839754e69d34346803dec4a3c38dca336d2fb0a50d2fa` |

元数据印证 Normal/Type/Tag/System 的节点类别数值，进一步的 CIL 检查确认新节点默认值、笔记标记和属性类型，见 [STATIC-EVIDENCE.md](STATIC-EVIDENCE.md)。没有恢复完整业务源码。运行配置 `TheBrain.Windows.App.runtimeconfig.json` 指向 `net6.0`、`Microsoft.NETCore.App 6.0.0` 和 `Microsoft.WindowsDesktop.App 6.0.0`。

Linux 的模型检查不包含桌面应用；后来完成的 Windows 应用测试仅覆盖上文列出的演示和 NIST 成品。具体复测步骤见 [FORMAT.md](FORMAT.md#分级验证及导入检查)；首次应导入可丢弃的独立测试脑图。工具没有实现云同步、完整归档导入器或通用数据库编辑。

本仓库也没有实际本地脑图数据库样本，`.dll` 存储的格式及直接改写路径仍未知。工具不会改写这些文件。
